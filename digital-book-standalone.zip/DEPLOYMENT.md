# دليل النشر على GitHub و Netlify

## الخطوة 1: إعداد GitHub

### 1.1 إنشاء مستودع جديد

1. اذهب إلى [GitHub](https://github.com)
2. اضغط على "New" لإنشاء مستودع جديد
3. أسمّ المستودع `digital-book`
4. اختر "Public" أو "Private"
5. اضغط "Create repository"

### 1.2 رفع الكود

```bash
# في مجلد المشروع
git init
git add .
git commit -m "Initial commit: Digital Book project"
git branch -M main
git remote add origin https://github.com/your-username/digital-book.git
git push -u origin main
```

## الخطوة 2: إعداد قاعدة البيانات

اختر أحد الخيارات التالية:

### الخيار 1: Railway (الأسهل والأفضل للمبتدئين)

1. اذهب إلى [Railway.app](https://railway.app)
2. اضغط "New Project"
3. اختر "Provision PostgreSQL"
4. انسخ رابط الاتصال (DATABASE_URL)

### الخيار 2: Render

1. اذهب إلى [Render.com](https://render.com)
2. اضغط "New +"
3. اختر "PostgreSQL"
4. اختر الخطة المجانية
5. انسخ رابط الاتصال

### الخيار 3: Heroku Postgres

1. اذهب إلى [Heroku](https://heroku.com)
2. أنشئ تطبيق جديد
3. أضف "Heroku Postgres" كـ add-on
4. انسخ رابط الاتصال

## الخطوة 3: النشر على Netlify

### 3.1 ربط GitHub مع Netlify

1. اذهب إلى [Netlify](https://netlify.com)
2. اضغط "New site from Git"
3. اختر GitHub
4. سجل دخول إلى GitHub إذا لزم الأمر
5. اختر مستودع `digital-book`

### 3.2 إعدادات البناء

في صفحة إعدادات البناء، أدخل:

- **Build command:** `pnpm run build`
- **Publish directory:** `dist`
- **Node version:** `22`

### 3.3 إضافة متغيرات البيئة

اضغط على "Environment" وأضف المتغيرات التالية:

```
DATABASE_URL = postgresql://user:password@host:5432/database
NODE_ENV = production
VITE_API_URL = https://your-site.netlify.app/api
```

### 3.4 النشر

اضغط "Deploy site" وانتظر انتهاء البناء.

## الخطوة 4: التحقق من النشر

1. افتح رابط الموقع الذي وفره Netlify
2. تحقق من أن الموقع يعمل بشكل صحيح
3. اختبر جميع الميزات

## استكشاف الأخطاء

### الموقع لا يحمّل

- تحقق من سجلات البناء في Netlify
- تأكد من أن جميع متغيرات البيئة صحيحة

### خطأ في قاعدة البيانات

- تحقق من رابط الاتصال (DATABASE_URL)
- تأكد من أن قاعدة البيانات تعمل

### الصفحات لا تحمّل بشكل صحيح

- تحقق من أن `netlify.toml` موجود
- تأكد من أن `dist` يحتوي على الملفات الصحيحة

## التحديثات المستقبلية

لتحديث الموقع:

```bash
git add .
git commit -m "Update: description of changes"
git push origin main
```

سيتم النشر تلقائياً على Netlify.

## الدعم

للمساعدة:
- [Netlify Docs](https://docs.netlify.com)
- [Railway Docs](https://docs.railway.app)
- [GitHub Docs](https://docs.github.com)
