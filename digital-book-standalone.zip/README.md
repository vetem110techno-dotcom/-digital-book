# السر الإلهي - الكتاب الرقمي التفاعلي

كتاب رقمي تفاعلي يحكي قصة السيدة رقية بنت الإمام الحسين عليه السلام ورجعتها إلى الحياة الدنيا.

## المميزات

- 📖 **قارئ كتاب تفاعلي** - تقليب صفحات سلس مع تأثيرات بصرية
- 🎨 **تصميم كلاسيكي حديث** - ألوان دافئة وذهبية فاخرة
- 🌙 **وضع ليلي** - قراءة مريحة في الليل
- 🔍 **بحث متقدم** - البحث عن النصوص داخل الكتاب
- 📑 **فهرس محتويات** - تنقل سريع بين الفصول
- 🔤 **تحكم بحجم الخط** - من 14px إلى 28px
- 🔖 **علامات مرجعية** - حفظ الصفحات المفضلة
- 🌐 **دعم كامل للعربية والإنجليزية** - RTL support

## المتطلبات

- Node.js 18+
- pnpm أو npm
- PostgreSQL 12+

## التثبيت

### 1. استنساخ المستودع

```bash
git clone https://github.com/your-username/digital-book.git
cd digital-book
```

### 2. تثبيت المكتبات

```bash
pnpm install
```

### 3. إعداد قاعدة البيانات

```bash
# إنشاء قاعدة بيانات PostgreSQL
createdb digital_book

# تشغيل الترحيلات
pnpm run db:migrate
```

### 4. إعداد متغيرات البيئة

انسخ `.env.example` إلى `.env` وعدّل القيم:

```bash
cp .env.example .env
```

ثم عدّل الملف:

```env
DATABASE_URL=postgresql://user:password@localhost:5432/digital_book
PORT=3000
NODE_ENV=development
VITE_API_URL=http://localhost:3000/api
```

## التطوير

### بدء خادم التطوير

```bash
pnpm run dev
```

سيتم فتح التطبيق على `http://localhost:5173`

### البناء للإنتاج

```bash
pnpm run build
```

### تشغيل الإنتاج

```bash
pnpm run start
```

## النشر على Netlify

### 1. إعداد GitHub

```bash
git add .
git commit -m "Initial commit"
git push origin main
```

### 2. ربط مع Netlify

1. اذهب إلى [Netlify](https://netlify.com)
2. اضغط "New site from Git"
3. اختر GitHub وحدد المستودع
4. في إعدادات البناء:
   - **Build command:** `pnpm run build`
   - **Publish directory:** `dist`
5. أضف متغيرات البيئة:
   - `DATABASE_URL`: رابط قاعدة البيانات
   - `NODE_ENV`: `production`
   - `VITE_API_URL`: رابط الخادم

### 3. نشر قاعدة البيانات

استخدم خدمة مثل:
- [Heroku Postgres](https://www.heroku.com/postgres)
- [Railway](https://railway.app)
- [Render](https://render.com)

## البنية

```
digital-book/
├── client/                 # تطبيق React
│   ├── src/
│   │   ├── components/    # مكونات React
│   │   ├── pages/         # الصفحات
│   │   ├── lib/           # المكتبات والبيانات
│   │   ├── contexts/      # React Contexts
│   │   ├── hooks/         # Custom Hooks
│   │   └── index.css      # الأنماط العامة
│   ├── index.html
│   └── vite.config.ts
├── server/                 # خادم Express
│   ├── index.ts           # نقطة الدخول
│   └── routes/            # المسارات
├── drizzle/               # قاعدة البيانات
│   ├── schema.ts          # تعريف الجداول
│   └── migrations/        # الترحيلات
├── package.json
├── tsconfig.json
├── vite.config.ts
└── README.md
```

## المساهمة

نرحب بالمساهمات! يرجى:

1. Fork المستودع
2. إنشاء فرع جديد (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push إلى الفرع (`git push origin feature/amazing-feature`)
5. فتح Pull Request

## الترخيص

هذا المشروع مرخص تحت MIT License - انظر ملف [LICENSE](LICENSE) للتفاصيل.

## الدعم

للأسئلة والدعم، يرجى فتح Issue في المستودع.

## التطوير المستقبلي

- [ ] إضافة نظام التعليقات والتفاعل
- [ ] نظام المستخدمين والحسابات
- [ ] إدارة الكتب المتعددة
- [ ] تطبيق الهاتف المحمول
- [ ] نظام التقييمات والمراجعات

---

تم إنشاؤه بـ ❤️ من قبل [اسمك]
