import React, { useState, useEffect } from 'react';
import { ChevronRight, ChevronLeft, Menu, Moon, Sun, ZoomIn, ZoomOut, Search, Bookmark } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { useTheme } from '@/contexts/ThemeContext';

interface StyledContent {
  text: string;
  color?: string;
  bold?: boolean;
  italic?: boolean;
}

interface Chapter {
  id: number;
  title: string;
  type?: 'cover' | 'title' | 'introduction' | 'chapter' | 'back-cover';
  chapterNumber?: number;
  content: (string | StyledContent)[];
}

interface BookReaderProps {
  chapters: Chapter[];
  bookTitle: string;
  bookAuthor: string;
}

const renderContent = (content: (string | StyledContent)[], fontSize: number) => {
  return content.map((item, idx) => {
    if (typeof item === 'string') {
      return (
        <span key={idx} style={{ fontSize: `${fontSize}px`, lineHeight: '1.8' }}>
          {item}
        </span>
      );
    } else {
      return (
        <span
          key={idx}
          style={{
            fontSize: `${fontSize}px`,
            lineHeight: '1.8',
            color: item.color || 'inherit',
            fontWeight: item.bold ? 'bold' : 'normal',
            fontStyle: item.italic ? 'italic' : 'normal',
          }}
        >
          {item.text}
        </span>
      );
    }
  });
};

export const BookReader: React.FC<BookReaderProps> = ({ chapters, bookTitle, bookAuthor }) => {
  const [currentPage, setCurrentPage] = useState(0);
  const [fontSize, setFontSize] = useState(18);
  const [showTableOfContents, setShowTableOfContents] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [bookmarks, setBookmarks] = useState<number[]>([]);
  const [hideUI, setHideUI] = useState(false);
  const { theme, toggleTheme } = useTheme();

  const totalPages = chapters.length;
  const currentChapter = chapters[currentPage];
  const isBookmarked = bookmarks.includes(currentPage);

  const handleNextPage = () => {
    if (currentPage < totalPages - 1) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleToggleBookmark = () => {
    if (isBookmarked) {
      setBookmarks(bookmarks.filter(p => p !== currentPage));
    } else {
      setBookmarks([...bookmarks, currentPage]);
    }
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query.trim()) {
      for (let i = 0; i < chapters.length; i++) {
        const content = chapters[i].content;
        const contentStr = content
          .map((item) => (typeof item === 'string' ? item : item.text))
          .join(' ');
        if (contentStr.toLowerCase().includes(query.toLowerCase())) {
          setCurrentPage(i);
          setShowSearch(false);
          break;
        }
      }
    }
  };

  const handleGoToChapter = (chapterIndex: number) => {
    setCurrentPage(chapterIndex);
    setShowTableOfContents(false);
  };

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') handleNextPage();
      if (e.key === 'ArrowLeft') handlePrevPage();
      if (e.key === 'Escape') setHideUI(!hideUI);
    };
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [currentPage, hideUI]);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col overflow-hidden">
      {/* Header */}
      {!hideUI && (
        <header className="border-b border-border bg-card shadow-sm">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-primary">{bookTitle}</h1>
              <p className="text-sm text-muted-foreground">{bookAuthor}</p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowSearch(true)}
                title="بحث (Ctrl+F)"
              >
                <Search className="w-5 h-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowTableOfContents(true)}
                title="فهرس المحتويات"
              >
                <Menu className="w-5 h-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                title={theme === 'dark' ? 'الوضع الفاتح' : 'الوضع الليلي'}
              >
                {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </header>
      )}

      {/* Main Content */}
      <main className="flex-1 overflow-auto" onClick={() => hideUI && setHideUI(false)}>
        <div className="container mx-auto px-4 py-12 max-w-4xl">
          {/* Book Page Display */}
          <div className="book-page min-h-[600px] relative">
            {/* Decorative Border */}
            <div className="absolute inset-0 border-2 border-accent/30 rounded-lg pointer-events-none" />

            {/* Page Number Indicator */}
            <div className="absolute top-6 right-6 text-sm text-muted-foreground">
              الصفحة {currentPage + 1} من {totalPages}
            </div>

            {/* Chapter Title */}
            <div className="mb-8 pb-6 border-b-2 border-accent/20">
              <h2 className="text-3xl font-bold text-primary mb-2">{currentChapter.title}</h2>
              <div className="flex gap-2 items-center">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleToggleBookmark}
                  className={isBookmarked ? 'text-accent' : ''}
                >
                  <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
                </Button>
                <span className="text-xs text-muted-foreground">
                  {isBookmarked ? 'مرجعي محفوظ' : 'إضافة مرجعي'}
                </span>
              </div>
            </div>

            {/* Chapter Content with Styled Text */}
            <div
              className="prose prose-sm max-w-none text-foreground leading-relaxed text-right"
              style={{ direction: 'rtl' }}
            >
              <div style={{ fontSize: `${fontSize}px`, lineHeight: '1.8', textAlign: 'right' }}>
                {renderContent(currentChapter.content, fontSize)}
              </div>
            </div>

            {/* Decorative Footer */}
            <div className="mt-12 pt-6 border-t-2 border-accent/20 text-center text-accent/50">
              ✦ ✦ ✦
            </div>
          </div>
        </div>
      </main>

      {/* Footer Controls */}
      {!hideUI && (
        <footer className="border-t border-border bg-card shadow-lg">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between gap-4">
              {/* Navigation */}
              <div className="flex items-center gap-2">
                <Button
                  onClick={handlePrevPage}
                  disabled={currentPage === 0}
                  variant="outline"
                  size="icon"
                  title="الصفحة السابقة (Arrow Left)"
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
                <span className="text-sm text-muted-foreground px-4">
                  {currentPage + 1} / {totalPages}
                </span>
                <Button
                  onClick={handleNextPage}
                  disabled={currentPage === totalPages - 1}
                  variant="outline"
                  size="icon"
                  title="الصفحة التالية (Arrow Right)"
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
              </div>

              {/* Font Size Controls */}
              <div className="flex items-center gap-2">
                <Button
                  onClick={() => setFontSize(Math.max(14, fontSize - 2))}
                  variant="outline"
                  size="icon"
                  title="تصغير الخط"
                >
                  <ZoomOut className="w-5 h-5" />
                </Button>
                <span className="text-sm text-muted-foreground px-2 min-w-[40px] text-center">
                  {fontSize}px
                </span>
                <Button
                  onClick={() => setFontSize(Math.min(28, fontSize + 2))}
                  variant="outline"
                  size="icon"
                  title="تكبير الخط"
                >
                  <ZoomIn className="w-5 h-5" />
                </Button>
              </div>

              {/* UI Toggle */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setHideUI(true)}
                className="text-xs"
              >
                إخفاء الواجهة (Esc)
              </Button>
            </div>

            {/* Progress Bar */}
            <div className="mt-4 w-full bg-muted rounded-full h-1 overflow-hidden">
              <div
                className="bg-accent h-full transition-all duration-300"
                style={{ width: `${((currentPage + 1) / totalPages) * 100}%` }}
              />
            </div>
          </div>
        </footer>
      )}

      {/* Table of Contents Dialog */}
      <Dialog open={showTableOfContents} onOpenChange={setShowTableOfContents}>
        <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>فهرس المحتويات</DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            {chapters.map((chapter, idx) => (
              <button
                key={idx}
                onClick={() => handleGoToChapter(idx)}
                className={`w-full text-right p-3 rounded-lg transition-colors ${
                  currentPage === idx
                    ? 'bg-accent text-accent-foreground'
                    : 'hover:bg-muted text-foreground'
                }`}
              >
                <div className="font-semibold">{chapter.title}</div>
                <div className="text-xs text-muted-foreground">الصفحة {idx + 1}</div>
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Search Dialog */}
      <Dialog open={showSearch} onOpenChange={setShowSearch}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>بحث في الكتاب</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="ابحث عن نص..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSearch(searchQuery);
                }
              }}
              autoFocus
            />
            <Button
              onClick={() => handleSearch(searchQuery)}
              className="w-full"
            >
              بحث
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BookReader;
