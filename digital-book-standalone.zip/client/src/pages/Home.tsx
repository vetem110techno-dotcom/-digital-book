import BookReader from '@/components/BookReader';
import { bookData } from '@/lib/bookData';

/**
 * Design Philosophy: Modern Classic Book Reader
 * - Warm cream backgrounds with golden accents
 * - Elegant typography with Playfair Display for titles and Lora for body
 * - RTL support for Arabic content
 * - Dark mode for comfortable night reading
 * - Interactive page flipping with smooth transitions
 */
export default function Home() {
  return (
    <BookReader
      chapters={bookData.chapters}
      bookTitle={bookData.title}
      bookAuthor={bookData.author}
    />
  );
}
